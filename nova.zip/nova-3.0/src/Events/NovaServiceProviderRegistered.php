<?php

namespace Laravel\Nova\Events;

use Illuminate\Foundation\Events\Dispatchable;

class NovaServiceProviderRegistered
{
    use Dispatchable;
}
