<template>
  <error-404 />
</template>
