<template>
  <div class="flex w-full justify-end items-center" />
</template>

<script>
export default {
  props: ['resource', 'resourceName', 'resourceId'],
}
</script>
